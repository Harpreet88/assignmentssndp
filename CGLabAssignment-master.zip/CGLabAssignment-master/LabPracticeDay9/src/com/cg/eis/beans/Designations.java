package com.cg.eis.beans;
public enum Designations 
{
	SystemAssociate,Programmer,Manager,Clerk;
}

