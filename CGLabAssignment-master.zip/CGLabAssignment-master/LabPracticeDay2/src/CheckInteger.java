
public class CheckInteger {

	public static void main(String[] args)
	{
		int num = Integer.parseInt(args[0]);
		if(num<0)
		{
			System.out.println("Negative Number");
		}
		else
			System.out.println("Positive Number");

	}

}
