package PersonValidation;

public enum PersonGender {
	M, F,U;

}
