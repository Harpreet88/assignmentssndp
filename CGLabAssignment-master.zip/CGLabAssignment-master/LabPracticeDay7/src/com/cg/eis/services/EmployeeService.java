package com.cg.eis.services;

public interface EmployeeService
{
	String findScheme(long salary,String designation);
}