package com.cg.lambdaexp.interfaces;
@FunctionalInterface
public interface FunctionalInterfacePower {
	int power(int x, int y);
}
