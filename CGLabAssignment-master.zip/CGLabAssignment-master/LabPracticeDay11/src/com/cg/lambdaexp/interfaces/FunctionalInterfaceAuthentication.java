package com.cg.lambdaexp.interfaces;
@FunctionalInterface
public interface FunctionalInterfaceAuthentication {
	boolean authenticateUser(String user, String pwd);
}
