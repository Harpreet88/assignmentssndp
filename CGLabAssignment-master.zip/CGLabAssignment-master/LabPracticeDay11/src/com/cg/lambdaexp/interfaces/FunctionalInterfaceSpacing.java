package com.cg.lambdaexp.interfaces;
@FunctionalInterface
public interface FunctionalInterfaceSpacing {
	String spacing(String str);
}
